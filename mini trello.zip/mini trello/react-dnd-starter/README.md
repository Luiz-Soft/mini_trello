# React Drag'n'Drop Starter

Learn to create a Trello Dashboard clone with React!
This is the starter repository for the React Drag'n'Drop Youtube video.

## Installation

Use the cmd line to install dependencies. 

```
npm install
```

## Usage

```
npm run build
npm run dev
```

## Contributing

Add your commit notes to commit.log
When committing use

```
git commit -F commmit.log
```
