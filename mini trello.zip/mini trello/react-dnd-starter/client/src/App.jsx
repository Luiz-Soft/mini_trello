import React from "react";
import Homepage from "./pages/Homepage";

const App = () => {
    return (
        <Homepage />
    );
};

export default App;