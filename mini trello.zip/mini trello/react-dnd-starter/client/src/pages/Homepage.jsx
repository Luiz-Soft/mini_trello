import React from "react";

const Homepage = props => {
    return (
        <div>
            Time to start coding!
        </div>
    );
};

export default Homepage;